import VolcanoStudio from '@/components/VolcanoStudio';

export default function StudioPage() {
  return <VolcanoStudio />;
}
